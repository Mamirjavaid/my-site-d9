/**
 * @file
 * Global utilities.
 *
 */
(function (Drupal) {

  'use strict';

  Drupal.behaviors.inteshape = {
    attach: function (context, settings) {

    }
  };

})(Drupal);
;
